package com.example.myapplication.models;

import java.util.Date;

public class ChatMessage {
    public String senderId, receiverId, message, dataTime;
    public Date dateObject;
}
