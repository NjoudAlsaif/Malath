package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import  java.util.*;
import androidx.appcompat.app.AppCompatActivity;
import  com.baoyachi.stepview.*;
import com.baoyachi.stepview.bean.StepBean;

import android.os.Bundle;
import android.widget.HorizontalScrollView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class status extends AppCompatActivity {
    private final String[] labels = {"Step 1", "Step 2", "Step 3", "Step 4", "Step 5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



            HorizontalStepView horizontalStepView = findViewById(R.id.step_view);

            horizontalStepView.setStepViewTexts(new ArrayList<StepBean>(){
            });


//        horizontalStepView
//                .setSteps(new ArrayList<String>() {{
//                    add("First step");
//                    add("Second step");
//                    add("Third step");
//                }})
//                ;
            List<StepBean> stepList = new ArrayList<>();
            stepList.add(new StepBean("Received the problem",1));
            stepList.add(new StepBean("work on it",1));
            stepList.add(new StepBean("problem solved", 1));
            horizontalStepView.setStepViewTexts(stepList);

            // State defaults to NOT_COMPLETED stepList.add(new Step("Amet"));
            // State defaults to NOT_COMPLETED horizontalStepView.setSteps(stepList);


        // Initialize and assign variable
        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);

        // Set Home selected
        bottomNavigationView.setSelectedItemId(R.id.status);

        // Perform item selected listener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch(item.getItemId())
                {
                    case R.id.awareness:
                        startActivity(new Intent(getApplicationContext(),awareness.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.status:
                        return true;
                    case R.id.contact:
                        startActivity(new Intent(getApplicationContext(),contact.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
}
    }


